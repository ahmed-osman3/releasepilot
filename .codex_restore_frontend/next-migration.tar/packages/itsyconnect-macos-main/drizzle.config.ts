import { defineConfig } from "drizzle-kit";

export default defineConfig({
  schema: "./src/db/schema.ts",
  out: "./drizzle",
  dialect: "sqlite",
  dbCredentials: {
    url: process.env.DATABASE_PATH ?? `${process.env.HOME}/Library/Application Support/Itsyconnect/itsyconnect.db`,
  },
});
